import pymysql
from flask import Flask, render_template, request, url_for, flash, redirect
import os
from datetime import datetime
from random import randint


import configparser

# from faker import Faker
# fake = Faker()

app = Flask(__name__)
path = os.path.dirname(__file__)

config_file = configparser.ConfigParser()
config_file.read(path + "/config.ini")  # Use if local
# config_file.read(path + "../../../../config.ini")  # Use if on server
config_file.sections()

conn = pymysql.connect(
    user=config_file["SETTINGS"]["USERNAME"],
    password=config_file["SETTINGS"]["PASSWORD"],
    host=config_file["DATABASE"]["HOST"],
    db=config_file["DATABASE"]["DB_NAME"],
    cursorclass=pymysql.cursors.DictCursor,
)


@app.route("/")
def index():
    with conn.cursor() as cur:
        cur = conn.cursor()
        res = cur.execute("SELECT * FROM oppslagstavle")
        tavle = cur.fetchall()

        cur = conn.cursor()
        res_2 = cur.execute("SELECT * FROM kategorier")
        kat = cur.fetchall()

        return render_template("index.html", tavle=tavle, kat=kat)


@app.route("/search=<int:var>")
def search(var):
    with conn.cursor() as cur:
        cur = conn.cursor()
        res = cur.execute("SELECT * FROM oppslagstavle WHERE kategori = %s", [var])
        tavle = cur.fetchall()

        cur = conn.cursor()
        res_2 = cur.execute("SELECT * FROM kategorier")
        kat = cur.fetchall()

        return render_template("search.html", tavle=tavle, kat=kat)


@app.route("/item=<int:var>")
def item(var):
    with conn.cursor() as cur:
        cur = conn.cursor()
        cur.execute("UPDATE oppslagstavle SET treff = treff + 1 WHERE id = %s", [var])
        conn.commit()
        cur.close()

        cur = conn.cursor()
        res = cur.execute("SELECT * FROM oppslagstavle WHERE id = %s", [var])
        tavle = cur.fetchall()

        cur = conn.cursor()
        res_2 = cur.execute("SELECT * FROM kategorier")
        kat = cur.fetchall()

        return render_template("item.html", tavle=tavle[0], kat=kat)


if __name__ == "__main__":
    app.run(debug=True)
