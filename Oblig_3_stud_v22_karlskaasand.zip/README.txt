Innlevering OBLIG 3 // stud_v22_karlskaasand // Anders Lea Karlskås
-------------------------------------------------------------------

Webadresse til fungerende demo: http://kark.kstudios.no


- Det var svært vanskelig å få kark.uit.no til å fungere, 
så jeg satt opp egen server for denne oppgaven. Det tok tid, men
da har dere ihvertfall en fungerende versjon å se på.


-------------------------------------------------------------------

Zipen inneholder:

app.py          - programfil, starter Flask
config.ini      - legg inn eget brukernavn til database
flask_app.wsgi  - Flask-config (til kark.uit.no)
/static         - komponentmappe (styles etc)
/templates      - htmlfiler
README.txt      - denne filen


-------------------------------------------------------------------
                        HA EN KNALL DAG!
-------------------------------------------------------------------